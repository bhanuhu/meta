import Card  from './component/Card';
import './App.css';
import Bottom from './component/Bottom';
import Mid from './component/Mid';
import Navbar from './component/Navbar';

function App() {
  return (
    <div className="App" >
      <Navbar/>
      <Mid/>
      <Bottom/>
      <Card/>
    </div>
  );
}

export default App;
