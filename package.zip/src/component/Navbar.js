const { Box, Stack, Typography, Button } = require("@mui/material")

const Navbar=()=>{
    return(<Box sx={{pt:'1%',boxShadow:5,pb:'1%'}}>
        <Stack direction="row">
            <Box sx={{ml:"1%" ,mt:'.5%'}}>
            <Typography>Title</Typography>
            </Box>
            <Box sx={{ml:"70%"}}>
            <Button sx={{color:'black'}} >Home</Button>
        <Button sx={{color:'black'}}>About</Button>
        <Button sx={{color:'black'}}>Blog</Button>
        <Button sx={{color:'black'}}>Contact</Button>
        <Button variant="outlined">Button</Button>
            </Box>
        
        


        </Stack>
    </Box>)
}
export default Navbar;