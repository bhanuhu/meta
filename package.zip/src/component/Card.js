import * as React from 'react';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { Box,Stack } from '@mui/material';

export default function MediaCard() {
  return (<Box sx={{mt:'3%',ml:"5%"}}>
    
  <Stack sx={{}}>
    <Stack direction="row" sx={{mb:'2%'}}>
    <Card sx={{ maxWidth: 345 ,mr:"1%",height:350 ,boxShadow:5}}>
      <Button sx={{width:'100%',height:'45%' ,backgroundColor:"grey",color:'white'}}>Add Image</Button>
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          Basic Technical Writting
        </Typography>
        <Typography variant="body2" color="text.secondary">
        This course focuses on understanding the basics of technical eriting and developing technical writing skills
        </Typography>
      </CardContent>
      <CardActions sx={{mb:'1%'}}>
        <Button size="small" variant='outlined' sx={{mb:"5%"}}>View</Button>
      </CardActions>
    </Card>
    <Card sx={{ maxWidth: 345 ,mr:"1%",height:350}}>
      <Button sx={{width:'100%',height:'45%' ,backgroundColor:"grey",color:'white'}}>Add Image</Button>
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          Basic Technical Writting
        </Typography>
        <Typography variant="body2" color="text.secondary">
        This course focuses on understanding the basics of technical eriting and developing technical writing skills
        </Typography>
      </CardContent>
      <CardActions>
        <Button size="small" variant='outlined'>View</Button>
      </CardActions>
    </Card>
    <Card sx={{ maxWidth: 345 ,mr:"1%",height:350}}>
      <Button sx={{width:'100%',height:'45%' ,backgroundColor:"grey",color:'white'}}>Add Image</Button>
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          Basic Technical Writting
        </Typography>
        <Typography variant="body2" color="text.secondary">
        This course focuses on understanding the basics of technical eriting and developing technical writing skills
        </Typography>
      </CardContent>
      <CardActions>
        <Button size="small" variant='outlined'>View</Button>
      </CardActions>
    </Card>

    </Stack>
    <Stack direction="row" sx={{mb:'2%'}}>
    <Card sx={{ maxWidth: 345 ,mr:"1%",height:350}}>
      <Button sx={{width:'100%',height:'45%' ,backgroundColor:"grey",color:'white'}}>Add Image</Button>>
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          Basic Technical Writting
        </Typography>
        <Typography variant="body2" color="text.secondary">
        This course focuses on understanding the basics of technical eriting and developing technical writing skills
        </Typography>
      </CardContent>
      <CardActions>
        <Button size="small" variant='outlined'>View</Button>
      </CardActions>
    </Card>
    <Card sx={{ maxWidth: 345 ,mr:"1%",height:350}}>
      <Button sx={{width:'100%',height:'45%' ,backgroundColor:"grey",color:'white'}}>Add Image</Button>
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          Basic Technical Writting
        </Typography>
        <Typography variant="body2" color="text.secondary">
        This course focuses on understanding the basics of technical eriting and developing technical writing skills
        </Typography>
      </CardContent>
      <CardActions>
        <Button size="small" variant='outlined'>View</Button>
      </CardActions>
    </Card>
    <Card sx={{ maxWidth: 345 ,mr:"1%",height:350}}>
      <Button sx={{width:'100%',height:'45%' ,backgroundColor:"grey",color:'white'}}>Add Image</Button>
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          Basic Technical Writting
        </Typography>
        <Typography variant="body2" color="text.secondary">
        This course focuses on understanding the basics of technical eriting and developing technical writing skills
        </Typography>
      </CardContent>
      <CardActions>
        <Button size="small" variant='outlined'>View</Button>
      </CardActions>
    </Card>

    </Stack><Stack direction="row" sx={{mb:'2%'}}>
    <Card sx={{ maxWidth: 345 ,mr:"1%",height:350}}>
      <Button sx={{width:'100%',height:'45%' ,backgroundColor:"grey",color:'white'}}>Add Image</Button>
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          Basic Technical Writting
        </Typography>
        <Typography variant="body2" color="text.secondary">
        This course focuses on understanding the basics of technical eriting and developing technical writing skills
        </Typography>
      </CardContent>
      <CardActions>
        <Button size="small" variant='outlined'>View</Button>
      </CardActions>
    </Card>
    <Card sx={{ maxWidth: 345 ,mr:"1%",height:350}}>
      <Button sx={{width:'100%',height:'45%' ,backgroundColor:"grey",color:'white'}}>Add Image</Button>
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          Basic Technical Writting
        </Typography>
        <Typography variant="body2" color="text.secondary">
        This course focuses on understanding the basics of technical eriting and developing technical writing skills
        </Typography>
      </CardContent>
      <CardActions>
        <Button size="small" variant='outlined'>View</Button>
      </CardActions>
    </Card>
    <Card sx={{ maxWidth: 345 ,mr:"1%",height:350}}>
      <Button sx={{width:'100%',height:'45%' ,backgroundColor:"grey",color:'white'}}>Add Image</Button>
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          Basic Technical Writting
        </Typography>
        <Typography variant="body2" color="text.secondary">
        This course focuses on understanding the basics of technical eriting and developing technical writing skills
        </Typography>
      </CardContent>
      <CardActions>
        <Button size="small" variant='outlined'>View</Button>
      </CardActions>
    </Card>

    </Stack>
    </Stack>
    </Box>
  );
}
