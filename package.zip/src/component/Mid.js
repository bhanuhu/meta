import { Box, Button, Typography } from "@mui/material"
import Card from "./Card";
const Mid=()=>{
    return(<Box sx={{mt:'2%',pt:'5%',pb:'5%'}}>
        
        <Typography variant="h4">Title</Typography>
        <Typography>Lorem ipsum dolor st amet, consectetur adipiscing elit. Maecenas risus</Typography>
        <Typography>    mi egestas et imperdiet quis, tristique non mi.</Typography>
        <Button variant="contained" sx={{color:"black",backgroundColor:"white"}}>Read More</Button>
    </Box>)
}
export default Mid;