import { Box, Typography } from "@mui/material"

const Bottom=()=>{
    return(<Box>
            <Typography variant="h4">Classes</Typography>
            <Typography>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas risus mi, egestas et imperdiet quis, tristique non mi</Typography>


    </Box>)
}
export default Bottom;